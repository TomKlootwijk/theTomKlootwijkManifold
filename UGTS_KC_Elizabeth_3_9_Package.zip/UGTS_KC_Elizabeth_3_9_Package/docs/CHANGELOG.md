# Changelog

## 3.9.0 - KC Elizabeth Vector Game-Creation Edition

- Preserves the complete KC 3.0 package and its 117 passing tests.
- Adds M330-M389, taking the combined engineering catalog to M389.
- Adds serializable vector paths, gradients, primitive factories, adaptive flattening and deterministic SVG export.
- Adds a dependency-free 2D collision and spatial-hash layer.
- Adds action-based keyboard, pointer, gamepad and touch input plus record/replay frames.
- Adds keyframe animation, easing, loops, ping-pong, crossfades and state machines.
- Adds layered tilemaps, ASCII import, A* pathfinding, flood search and merged collision boxes.
- Adds procedural sound cues, ADSR envelopes, note parsing and beat sequences.
- Adds a deterministic entity/component game world with fixed-step movement, collision lifecycle events, player dash, health, hazards, collectibles, bounds, cameras, snapshots, state hashes and saves.
- Adds a validated game-project model and schema shared across Python and browser output.
- Adds a self-contained Canvas/Web Audio HTML5 runtime with keyboard, gamepad, touch, HUD, particles, pause/restart, save/load, mute and diagnostics.
- Adds a CLI for project creation, validation, headless simulation, browser builds and SVG export.
- Adds Elizabeth's Vector Garden as a complete editable and browser-playable example.
- Adds 108 tests; the complete package now runs 225 tests.

## 3.0.0 - Interactive Graphics and Two-Hand Runtime Companion

- Retains M001-M257 by source/reference and appends M258-M329.
- Adds scene assets, nodes, layers, transforms, migration and content hashes.
- Adds adaptive curve compilation, strokes, swept tubes and marching tetrahedra.
- Adds AABB/BVH/frustum/ray/streaming/interest queries.
- Adds PBR preview materials, color transforms and a small material graph.
- Adds typed left/right hand input, pinch hysteresis, bimanual transforms and handover lineage.
- Adds deterministic event proposal commit, snapshots, checkpoints, replay and divergence detection.
- Adds SVG, glTF and USDA output adapters.
- Adds a complete runnable sandbox and 70 new tests; the package runs 117 tests total with the retained 2.0 suite.

## 2.0.0 - Pattern, Kinematic Calculus and Dynamics Expansion

- Added M198-M257 and 47 tests.
