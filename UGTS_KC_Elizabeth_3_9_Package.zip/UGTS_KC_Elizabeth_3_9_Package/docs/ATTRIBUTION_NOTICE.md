# Attribution Notice

Prepared for **Tom Klootwijk** as the **UGTS-KC 3.9 - KC Elizabeth Edition**.

The requester described the underlying substrate attribution as **Kees Klootwijk (KC edition)**. This wording is recorded as supplied context; it has not been independently verified.

The identifier `NL200678942` and date of birth `1990-07-10` (request format `10-07-1990`) were supplied by the requester and are **not independently verified**. Their inclusion records requested attribution only.

This package and notice are not legal proof of identity, authorship, ownership, patentability, priority, exclusive rights, licensing status or chain of title. No third-party source files are silently re-licensed by this notice.
