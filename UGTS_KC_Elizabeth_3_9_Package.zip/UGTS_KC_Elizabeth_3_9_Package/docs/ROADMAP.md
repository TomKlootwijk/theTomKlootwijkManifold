# Post-3.9 Production Roadmap

1. Add an optional Rust core and stable C ABI while retaining Python as the deterministic oracle.
2. Add a visual editor that writes the same project schema without becoming runtime state authority.
3. Add sprite/image/font asset records while preserving the vector-first path.
4. Add topology-aware polygon decomposition and continuous collision for fast circles/polygons.
5. Add joints, character sweeps, one-way platforms and richer conventional physics fallback.
6. Compile animation state machines directly into browser runtime records and add skeletal animation separately.
7. Add tilemap rendering, chunk streaming and navigation-cost fields to the browser runtime.
8. Add import adapters for SVG subsets, glTF scenes and OpenUSD composition without replacing canonical IDs.
9. Add WebGPU presentation as an optional backend using the same project/game records.
10. Add server-authoritative replication, input transport, checkpoints and rollback proof tests.
11. Add browser automation across Chromium, Firefox and WebKit plus mobile-device test coverage.
12. Benchmark equal-error workloads against conventional Canvas/WebGL engines and retain kill criteria for features that do not provide measurable value.
