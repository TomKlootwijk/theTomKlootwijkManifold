# Evidence Boundary - KC Elizabeth 3.9

## Demonstrated by this archive

- The Python source compiles and its 225 automated tests pass in the captured release environment.
- The original KC 2.0/3.0 modules and tests remain present and passing.
- Project JSON can be validated, serialized, loaded, instantiated and hashed deterministically.
- Game-world snapshots can be saved, loaded and reproduced with equal canonical state hashes.
- Vector assets can be serialized and exported as SVG.
- The example project can be built into a self-contained HTML5/Canvas/Web Audio game.
- The generated JavaScript passes syntax validation in Node.js.
- The example's browser runtime implements keyboard, gamepad and touch input, fixed-step updates, collisions, scoring, health, audio, HUD, particles, pause/restart, persistence and diagnostics.

## Reference implementation boundary

The Python game world is a deterministic reference/oracle and headless simulation layer. The HTML5 output is a practical playable runtime. Neither is represented as a replacement for every subsystem of a mature commercial engine.

## Not claimed

- Native Vulkan, Direct3D, Metal or physical-device WebGPU execution.
- General continuous rigid-body dynamics, joints, deformables or certified collision robustness.
- Skeletal character animation, inverse-kinematics authoring tools or animation retargeting.
- Production multiplayer transport, anti-cheat, matchmaking or server operations.
- Console platform SDK support or store/platform certification.
- OpenXR runtime integration.
- Full OpenUSD, MaterialX or OCIO implementation.
- Security certification of browser saves or project files.
- Independent verification of requester identity, attribution or ownership assertions.

## Determinism scope

State hashes use canonical JSON and normalize numerically equivalent integral values (`1` and `1.0`). Determinism is expected for the same runtime version, project data, fixed time step and input sequence. Cross-language floating-point bit identity is not claimed; browser and Python runtimes share project semantics but are separate implementations.
