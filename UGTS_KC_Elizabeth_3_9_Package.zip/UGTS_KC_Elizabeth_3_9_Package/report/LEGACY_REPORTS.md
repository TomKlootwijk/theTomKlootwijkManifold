# Report History

The original KC Two Hands 3.0 PDF and DOCX are preserved under `report/legacy_3_0/` as historical evidence for the supplied baseline.

The current release report is:

- `UGTS_KC_3_9_KC_Elizabeth_Vector_Game_Runtime.docx`
- `UGTS_KC_3_9_KC_Elizabeth_Vector_Game_Runtime.pdf`
