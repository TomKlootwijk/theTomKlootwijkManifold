from setuptools import find_packages, setup

setup(
    name="ugts-kc-elizabeth",
    version="3.9.0",
    package_dir={"": "src"},
    packages=find_packages("src"),
    package_data={"": ["py.typed"]},
    description="UGTS-KC 3.9 KC Elizabeth vector graphics, deterministic game runtime and HTML5 exporter",
    python_requires=">=3.10",
    entry_points={"console_scripts": ["ugts-kc=ugts_kc3.cli:main"]},
)
