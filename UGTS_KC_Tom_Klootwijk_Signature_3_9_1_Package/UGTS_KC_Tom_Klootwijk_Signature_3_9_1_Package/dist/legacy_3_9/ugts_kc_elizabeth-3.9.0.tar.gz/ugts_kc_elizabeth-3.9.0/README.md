# UGTS-KC 3.9 - KC Elizabeth Edition
## Vector Art and Deterministic Game-Creation Runtime

UGTS-KC 3.9 upgrades the supplied **UGTS-KC Two Hands 3.0** archive into a practical, dependency-free 2D game-creation stack while retaining the complete 3.0 scene, geometry, spatial, material, hand-interaction, deterministic event, replay and interchange APIs.

The release keeps the original authority path:

```text
local/spatial support -> compatibility -> guard classification
-> verified proposal -> deterministic event commit
-> scene/topology/dynamic patch -> lineage + replay log
-> optional render/export
```

It adds a game-production path around that foundation:

```text
vector assets + input actions + scene project
-> fixed-step game world + collision/gameplay systems
-> deterministic snapshot/hash/save
-> Canvas/Web Audio HTML5 build
-> keyboard + gamepad + touch play
```

The source-normalized baseline contains 197 mechanisms. KC 2.0 added M198-M257, KC 3.0 added M258-M329, and KC Elizabeth 3.9 adds **M330-M389**. The combined engineering catalog now reaches **389 mechanisms**.

## What is new in 3.9

- Serializable 2D vector paths, fills, strokes, linear/radial gradients, reusable libraries, primitive factories, adaptive flattening and SVG output.
- AABB, circle and convex-polygon collision; mixed manifolds; masks/layers; sensors; swept AABB tests; and spatial hashing.
- Action-based keyboard, pointer, gamepad and touch input with deadzones, edge detection and recording.
- Keyframe tracks, easing, looping, ping-pong playback, crossfades and animation state machines.
- Layered tilemaps, ASCII import, coordinate conversion, flood search, A* pathfinding and merged collision rectangles.
- Procedural Web Audio sound cues, note parsing, ADSR envelopes and beat sequences.
- A deterministic 2D entity/component game world with physics, collision events, player movement/dash, health, hazards, collectibles, lifetimes, cameras, bounds, snapshots, hashes and save/load.
- A validated JSON game-project model shared by Python simulation and the browser build.
- A self-contained HTML5 Canvas exporter with no external libraries or network assets.
- A command-line workflow for creating, validating, simulating, building and exporting projects.
- **Elizabeth's Vector Garden**, a complete browser-playable demonstration project.

## Run the included game

Open this file in a modern browser:

```text
examples/elizabeth_vector_quest/dist/index.html
```

Controls: WASD or arrow keys to move, Space/Shift or gamepad button 0 to dash, P to pause, R to restart, K to save, L to load, M to mute and F3 for diagnostics. Touch controls appear on touch-capable devices.

## Command-line quick start

From this package directory:

```bash
# Runtime information
PYTHONPATH=src python -m ugts_kc3 info

# Create a blank project and build it
PYTHONPATH=src python -m ugts_kc3 new my_game --title "My Vector Game" --author "Your Name" --build

# Create the Elizabeth demo project
PYTHONPATH=src python -m ugts_kc3 demo my_elizabeth_demo --author "Your Name"

# Validate, simulate and rebuild an existing project
PYTHONPATH=src python -m ugts_kc3 validate my_game/project.json
PYTHONPATH=src python -m ugts_kc3 simulate my_game/project.json --steps 240 --move-x 1 --json
PYTHONPATH=src python -m ugts_kc3 build-web my_game/project.json my_game/dist
```

An installed package also provides the `ugts-kc` command.

## Python quick start

```python
from ugts_kc3 import (
    Body2D, Circle2, Collider2D, GameWorld,
    Transform2D, VectorPaint, circle_asset,
)

player_art = circle_asset("player", 18, fill="#72e7ff", stroke="#ffffff")
world = GameWorld(fixed_dt=1 / 60)
world.spawn(
    "player",
    tags=("player",),
    components=(
        Transform2D((100, 100)),
        Body2D(velocity=(80, 0), gravity_scale=0),
        Collider2D(Circle2((0, 0), 18)),
    ),
)
world.step(steps=60)
print(world.require("player", Transform2D).position)
print(world.state_hash())
```

## Validation status

- **225 automated tests pass**: the retained 117-test KC 2.0/3.0 suite plus 108 tests for the Elizabeth game stack.
- Python bytecode compilation passes.
- Project/schema/catalog validation passes.
- The generated browser runtime passes Node.js syntax validation.
- The demonstration build is generated from its checked-in `project.json` and contains no third-party runtime dependency.

Captured evidence is under `validation/`.

## Package layout

- `src/ugts_kc/` - retained KC 2.0 pattern, topology, kinematics, field, dynamics and event oracle.
- `src/ugts_kc3/` - retained 3.0 runtime plus the new 3.9 vector/game/project/browser modules.
- `examples/elizabeth_vector_quest/` - editable project, SVG assets and browser-playable build.
- `templates/` - blank and full sample project templates.
- `spec/` - contracts, JSON schema and mechanism catalogs through M389.
- `docs/` - practical guides, migration notes, evidence boundary, changelog and roadmap.
- `report/` - 3.9 technical report plus retained 3.0 legacy reports.
- `tests/` - 225 automated tests.
- `validation/` - release evidence, manifests, hashes and retained 3.0 evidence.

## Compatibility

The public modules and tests from the supplied 3.0 package remain present. New functionality is additive under `ugts_kc3`; the game-project schema is explicitly versioned as `ugts-kc-game-project-3.9`.

## Boundary

This is a tested reference implementation and browser-ready vertical slice, not a claim of a native AAA engine. It does not claim a production Vulkan/WebGPU renderer, general rigid-body engine, skeletal animation suite, multiplayer service, console certification, OpenXR binding or third-party platform SDK integration. See `docs/EVIDENCE_BOUNDARY.md`.

## Attribution

Prepared for **Tom Klootwijk** as the **KC Elizabeth Edition**, with **Kees Klootwijk** recorded as the requester-described substrate attribution. The supplied identifier and date of birth remain requester-supplied and independently unverified. See `docs/ATTRIBUTION_NOTICE.md`.
