"""Release identity for UGTS-KC 3.9 — KC Elizabeth edition."""

__version__ = "3.9.0"
__codename__ = "KC Elizabeth"
__edition__ = "3.9 - KC - Elizabeth"
__game_project_schema__ = "ugts-kc-game-project-3.9"
