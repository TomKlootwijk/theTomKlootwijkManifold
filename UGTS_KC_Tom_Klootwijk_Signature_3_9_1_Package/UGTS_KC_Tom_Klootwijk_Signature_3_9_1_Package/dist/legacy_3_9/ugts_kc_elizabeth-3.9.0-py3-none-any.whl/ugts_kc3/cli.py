"""Command-line project creation, validation, simulation and HTML5 building."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .game_input import InputFrame
from .project import GameProject
from .templates import blank_vector_game_project, elizabeth_vector_quest_project
from .vector2d import write_vector_svg
from .version import __codename__, __edition__, __version__
from .webexport import build_html5


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ugts-kc",
        description=f"UGTS-KC {__version__} — {__codename__} vector-game creation tools",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("info", help="show runtime and edition information")

    new = sub.add_parser("new", help="create a starter game project")
    new.add_argument("directory", type=Path)
    new.add_argument("--title", default="My KC Elizabeth Game")
    new.add_argument("--author", default="")
    new.add_argument("--template", choices=("blank", "elizabeth-quest"), default="blank")
    new.add_argument("--build", action="store_true", help="also build an HTML5 dist directory")

    validate = sub.add_parser("validate", help="validate a project.json file")
    validate.add_argument("project", type=Path)
    validate.add_argument("--json", action="store_true", dest="as_json")

    build = sub.add_parser("build-web", help="build a browser-playable HTML5 game")
    build.add_argument("project", type=Path)
    build.add_argument("output", type=Path)
    build.add_argument("--bundle", action="store_true", help="write runtime JavaScript separately instead of one HTML file")
    build.add_argument("--no-clean", action="store_true")

    simulate = sub.add_parser("simulate", help="run a headless deterministic simulation")
    simulate.add_argument("project", type=Path)
    simulate.add_argument("--scene")
    simulate.add_argument("--steps", type=int, default=120)
    simulate.add_argument("--move-x", type=float, default=0.0)
    simulate.add_argument("--move-y", type=float, default=0.0)
    simulate.add_argument("--dash-at", type=int, default=-1)
    simulate.add_argument("--json", action="store_true", dest="as_json")

    svg = sub.add_parser("export-svg", help="write every vector asset as an SVG file")
    svg.add_argument("project", type=Path)
    svg.add_argument("output", type=Path)
    svg.add_argument("--background")

    demo = sub.add_parser("demo", help="write and build Elizabeth's Vector Garden demo")
    demo.add_argument("directory", type=Path)
    demo.add_argument("--author", default="Tom Klootwijk")

    return parser


def _print_report(project: GameProject, as_json: bool) -> int:
    report = project.validate(raise_on_error=False)
    if as_json:
        print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
    else:
        status = "PASS" if report.passed else "FAIL"
        print(f"{status}: {project.metadata.title} ({project.metadata.id})")
        for key, value in report.metrics.items():
            print(f"  {key}: {value}")
        for issue in report.issues:
            print(f"  {issue.severity.upper()} {issue.code} {issue.path}: {issue.message}")
    return 0 if report.passed else 2


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "info":
            print(f"UGTS-KC {__version__}")
            print(f"Edition: {__edition__}")
            print("Capabilities: vector assets, deterministic game world, input, collision/physics, animation, tilemaps/A*, procedural audio, project validation and HTML5 Canvas export")
            return 0

        if args.command == "new":
            project = elizabeth_vector_quest_project(args.author) if args.template == "elizabeth-quest" else blank_vector_game_project(args.title, args.author)
            args.directory.mkdir(parents=True, exist_ok=True)
            project_path = project.write(args.directory / "project.json")
            (args.directory / "README.md").write_text(
                f"# {project.metadata.title}\n\nValidate and build:\n\n```bash\npython -m ugts_kc3 validate project.json\npython -m ugts_kc3 build-web project.json dist\n```\n",
                encoding="utf-8",
            )
            print(project_path)
            if args.build:
                result = build_html5(project, args.directory / "dist")
                print(result.entrypoint)
            return 0

        if args.command == "validate":
            return _print_report(GameProject.load(args.project, validate=False), args.as_json)

        if args.command == "build-web":
            project = GameProject.load(args.project)
            result = build_html5(project, args.output, single_file=not args.bundle, clean=not args.no_clean)
            print(result.entrypoint)
            print(f"{len(result.files)} files, {result.total_bytes} bytes, project {result.project_hash[:12]}")
            return 0

        if args.command == "simulate":
            project = GameProject.load(args.project)
            world = project.instantiate_world(args.scene)
            previous = None
            for step in range(args.steps):
                values = {"move_x": args.move_x, "move_y": args.move_y, "dash": 1.0 if step == args.dash_at else 0.0}
                frame = project.input_map.frame_from_actions(values, previous)
                world.step(frame)
                previous = frame
            summary = {
                "schema": "ugts-kc-headless-summary-3.9",
                "steps": args.steps,
                "tick": world.tick,
                "time": world.time,
                "entities": len(world.entities),
                "state": world.state,
                "events": len(world.events),
                "state_hash": world.state_hash(),
            }
            if args.as_json:
                print(json.dumps(summary, indent=2, sort_keys=True))
            else:
                for key, value in summary.items():
                    print(f"{key}: {value}")
            return 0

        if args.command == "export-svg":
            project = GameProject.load(args.project)
            args.output.mkdir(parents=True, exist_ok=True)
            for asset in project.vector_assets:
                write_vector_svg(asset, args.output / f"{asset.id}.svg", args.background, padding=8)
            print(f"wrote {len(project.vector_assets.assets)} SVG assets to {args.output}")
            return 0

        if args.command == "demo":
            args.directory.mkdir(parents=True, exist_ok=True)
            project = elizabeth_vector_quest_project(args.author)
            project.write(args.directory / "project.json")
            result = build_html5(project, args.directory / "dist")
            print(result.entrypoint)
            return 0

        raise AssertionError("unreachable command")
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
